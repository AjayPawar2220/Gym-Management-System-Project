

<?php



    $host = "localhost";
    $user = "root";
    $password ="";
    $database = "loginsystem";

$Member_ID = "";
$First_Name = "";
$Last_Name = "";

try{
    $connect = mysqli_connect($host, $user, $password, $database);
} catch (mysqli_sql_exception $ex) {
    echo 'Error';
}

function getPosts()
{
    $posts = array();
    $posts[0] = $_POST['Member_ID'];
    $posts[1] = $_POST['First_Name'];
    $posts[2] = $_POST['Last_Name'];
    
    return $posts;
}

       
if(isset($_POST['delete']))
{
    $data = getPosts();
    $delete_Query = "DELETE FROM `member_registration` WHERE `contact` = $data[0]";
    try{
        $delete_Result = mysqli_query($connect, $delete_Query);
        
        if($delete_Result)
        {
            if(mysqli_affected_rows($connect) > 0)
            {
                //echo 'Data Deleted';
                echo "<script>alert('Data Deleted');</script>";
            }else{
                echo 'Data Not Deleted';
            }
        }
    } catch (Exception $ex) {
        echo 'Error Delete '.$ex->getMessage();
    }
}

if(isset($_POST['update']))
{
    $data = getPosts();
    $update_Query = "UPDATE `member_registration` SET `fname`='$data[1]',`lname`='$data[2]' WHERE `contact` = $data[0]";
    try{
        $update_Result = mysqli_query($connect, $update_Query);
        
        if($update_Result)
        {
            if(mysqli_affected_rows($connect) > 0)
            {
                echo 'Data Updated';
            }else{
                echo 'Data Not Updated';
            }
        }
    } catch (Exception $ex) {
        echo 'Error Update '.$ex->getMessage();
    }
}

if(isset($_POST['search']))
{
    $data = getPosts();
    
    $search_Query = "SELECT * FROM member_registration WHERE contact = $data[0]";
    
    $search_Result = mysqli_query($connect, $search_Query);
    
    if($search_Result)
    {
        if(mysqli_num_rows($search_Result))
        {
            while($row = mysqli_fetch_array($search_Result))
            {
                $contact = $row['contact'];
                $fname = $row['fname'];
                $lname = $row['lname'];
                echo"$contact<br>";
                echo"$fname<br>";
                echo"$lname<br>";

                
            }
        }else{
            echo 'No Data For This Id';
        }
    }else{
        echo 'Result Error';
    }
}

?>
